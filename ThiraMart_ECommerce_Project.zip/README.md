# ThiraMart — E-Commerce Web Application

A complete beginner-friendly full-stack e-commerce project for the ThiraNex assignment.

## Features

- Product catalog with search
- Add to cart and quantity management
- Checkout and order creation
- User registration/login
- JWT authentication
- Admin/User role-based access
- Admin product CRUD
- Admin order management and status updates
- MongoDB database integration
- Responsive frontend
- Order tracking for users

## Technology

- Frontend: HTML, CSS, Vanilla JavaScript
- Backend: Node.js + Express
- Database: MongoDB + Mongoose
- Authentication: JWT + bcrypt

## Requirements

Install Node.js and MongoDB locally, or use MongoDB Atlas.

## Run locally

1. Open the project folder in VS Code.
2. Copy `.env.example` to `.env`.
3. Put your MongoDB connection string in `.env`.
4. Install packages:

   `npm install`

5. Insert demo data:

   `node seed.js`

6. Start the server:

   `npm start`

7. Open:

   `http://localhost:5000`

## Demo accounts

Admin:
- Email: admin@thiramart.com
- Password: Admin@123

User:
- Email: user@thiramart.com
- Password: User@123

## GitHub

Upload the whole project folder to a GitHub repository. Do NOT upload `.env` or `node_modules`.

## API endpoints

Auth:
- POST `/api/auth/register`
- POST `/api/auth/login`
- GET `/api/auth/me`

Products:
- GET `/api/products`
- GET `/api/products/:id`
- POST `/api/products` (Admin)
- PUT `/api/products/:id` (Admin)
- DELETE `/api/products/:id` (Admin)

Orders:
- POST `/api/orders`
- GET `/api/orders/my`
- GET `/api/orders` (Admin)
- PATCH `/api/orders/:id/status` (Admin)
