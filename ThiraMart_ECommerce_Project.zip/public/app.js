const API = "/api";
let token = localStorage.getItem("token") || "";
let currentUser = JSON.parse(localStorage.getItem("user") || "null");
let cart = JSON.parse(localStorage.getItem("cart") || "[]");
let productsCache = [];
let authMode = "login";

const $ = id => document.getElementById(id);
const money = n => "₹" + Number(n).toLocaleString("en-IN");

function saveCart(){ localStorage.setItem("cart", JSON.stringify(cart)); updateCartCount(); }
function updateCartCount(){ $("cartCount").textContent = cart.reduce((s,i)=>s+i.quantity,0); }
function toast(msg){ $("toast").textContent=msg; $("toast").style.display="block"; setTimeout(()=>$("toast").style.display="none",2200); }

async function api(path, options={}) {
  const headers = {"Content-Type":"application/json", ...(options.headers||{})};
  if(token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch(API+path, {...options, headers});
  const data = await res.json().catch(()=>({}));
  if(!res.ok) throw new Error(data.message || "Something went wrong");
  return data;
}

function showOnly(id){
  ["homePage","ordersPage","adminPage"].forEach(x=>$(x).classList.toggle("hidden",x!==id));
}
function showHome(){showOnly("homePage");loadProducts();}
async function loadProducts(){
  try{
    const search = encodeURIComponent($("searchInput")?.value || "");
    const data = await api(`/products${search?`?search=${search}`:""}`);
    productsCache=data.products;
    renderProducts(data.products);
  }catch(e){toast(e.message)}
}
function renderProducts(list){
  const box=$("products");
  if(!list.length){box.innerHTML='<div class="empty">No products found.</div>';return}
  box.innerHTML=list.map(p=>`
    <article class="product">
      <img src="${p.image}" alt="${escapeHtml(p.name)}">
      <div class="product-body">
        <small class="stock">${escapeHtml(p.category)} • ${p.stock} in stock</small>
        <h3>${escapeHtml(p.name)}</h3>
        <p>${escapeHtml(p.description)}</p>
        <div class="product-actions">
          <span class="price">${money(p.price)}</span>
          <button onclick="addToCart('${p._id}')">Add to Cart</button>
        </div>
      </div>
    </article>`).join("");
}
function escapeHtml(s=""){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}

function addToCart(id){
  const p=productsCache.find(x=>x._id===id);
  if(!p) return;
  const found=cart.find(x=>x.product===id);
  if(found){
    if(found.quantity>=p.stock)return toast("Stock limit reached");
    found.quantity++;
  }else cart.push({product:p._id,name:p.name,price:p.price,image:p.image,quantity:1});
  saveCart();toast("Added to cart");
}
function openCart(){
  renderCart();$("cartModal").classList.remove("hidden");
}
function renderCart(){
  const box=$("cartItems");
  if(!cart.length){box.innerHTML='<div class="empty">Your cart is empty.</div>';$("cartTotal").textContent=money(0);return}
  box.innerHTML=cart.map(i=>`
    <div class="cart-item">
      <img src="${i.image}">
      <div class="cart-item-main"><strong>${escapeHtml(i.name)}</strong><br><span>${money(i.price)}</span></div>
      <div class="qty"><button onclick="changeQty('${i.product}',-1)">−</button> ${i.quantity} <button onclick="changeQty('${i.product}',1)">+</button></div>
    </div>`).join("");
  $("cartTotal").textContent=money(cart.reduce((s,i)=>s+i.price*i.quantity,0));
}
function changeQty(id,d){
  const i=cart.find(x=>x.product===id);if(!i)return;
  i.quantity+=d;if(i.quantity<=0)cart=cart.filter(x=>x.product!==id);
  saveCart();renderCart();
}
function openAuth(){authMode="login";renderAuth();$("authModal").classList.remove("hidden")}
function renderAuth(){
  $("authTitle").textContent=authMode==="login"?"Login":"Create Account";
  $("nameField").classList.toggle("hidden",authMode==="login");
  $("authSwitch").textContent=authMode==="login"?"New here? Create an account":"Already have an account? Login";
}
$("authSwitch").onclick=()=>{authMode=authMode==="login"?"register":"login";renderAuth()};
$("authForm").onsubmit=async e=>{
  e.preventDefault();
  try{
    const body={email:$("emailField").value,password:$("passwordField").value};
    if(authMode==="register")body.name=$("nameField").value;
    const d=await api(`/auth/${authMode}`,{method:"POST",body:JSON.stringify(body)});
    token=d.token;currentUser=d.user;
    localStorage.setItem("token",token);localStorage.setItem("user",JSON.stringify(currentUser));
    closeModal("authModal");refreshNav();toast("Welcome, "+currentUser.name);
  }catch(err){toast(err.message)}
};
function logout(){
  token="";currentUser=null;localStorage.removeItem("token");localStorage.removeItem("user");refreshNav();showHome();toast("Logged out");
}
function refreshNav(){
  $("authNav").classList.toggle("hidden",!!currentUser);
  $("logoutNav").classList.toggle("hidden",!currentUser);
  $("adminNav").classList.toggle("hidden",currentUser?.role!=="admin");
}
function closeModal(id){$(id).classList.add("hidden")}

async function checkout(){
  if(!cart.length)return toast("Cart is empty");
  if(!currentUser){closeModal("cartModal");openAuth();return}
  closeModal("cartModal");$("checkoutModal").classList.remove("hidden");
}
async function placeOrder(){
  const address=$("addressField").value.trim();
  if(!address)return toast("Enter delivery address");
  try{
    const d=await api("/orders",{method:"POST",body:JSON.stringify({items:cart.map(i=>({product:i.product,quantity:i.quantity})),shippingAddress:address})});
    cart=[];saveCart();$("addressField").value="";closeModal("checkoutModal");toast("Order placed successfully");showOrders();
  }catch(e){toast(e.message)}
}
async function showOrders(){
  showOnly("ordersPage");
  if(!currentUser){$("ordersList").innerHTML='<div class="empty">Please login to see your orders.</div>';return}
  try{
    const d=await api("/orders/my");
    $("ordersList").innerHTML=d.orders.length?d.orders.map(o=>`
      <div class="order-card">
        <div class="order-top"><div><strong>Order #${o._id.slice(-8).toUpperCase()}</strong><p class="muted">${new Date(o.createdAt).toLocaleString()}</p></div><span class="status">${o.status}</span></div>
        <p>${o.items.map(i=>`${escapeHtml(i.name)} × ${i.quantity}`).join(" • ")}</p>
        <strong>Total: ${money(o.total)}</strong>
        <p class="muted">Delivery: ${escapeHtml(o.shippingAddress)}</p>
      </div>`).join(""):'<div class="empty">No orders yet. Start shopping!</div>';
  }catch(e){$("ordersList").innerHTML=`<div class="empty">${escapeHtml(e.message)}</div>`}
}
async function showAdmin(){
  if(currentUser?.role!=="admin")return toast("Admin access required");
  showOnly("adminPage");await loadAdminProducts();await loadAdminOrders();
}
async function loadAdminProducts(){
  const d=await api("/products");
  $("adminProducts").innerHTML=d.products.map(p=>`
    <div class="admin-row">
      <span><strong>${escapeHtml(p.name)}</strong><br><small>${money(p.price)} • Stock ${p.stock}</small></span>
      <span><button onclick='editProduct(${JSON.stringify(p)})'>Edit</button><button class="danger" onclick="deleteProduct('${p._id}')">Delete</button></span>
    </div>`).join("");
}
async function loadAdminOrders(){
  const d=await api("/orders");
  $("adminOrders").innerHTML=d.orders.length?d.orders.map(o=>`
    <div class="admin-row">
      <span><strong>#${o._id.slice(-7).toUpperCase()}</strong><br><small>${escapeHtml(o.user?.name||"User")} • ${money(o.total)}</small></span>
      <select class="mini-select" onchange="updateStatus('${o._id}',this.value)">
        ${["Pending","Processing","Shipped","Delivered","Cancelled"].map(s=>`<option ${s===o.status?"selected":""}>${s}</option>`).join("")}
      </select>
    </div>`).join(""):'<div class="empty">No orders.</div>';
}
function openProductForm(p=null){
  $("productFormTitle").textContent=p?"Edit Product":"Add Product";
  $("productId").value=p?._id||"";$("pName").value=p?.name||"";$("pPrice").value=p?.price??"";$("pStock").value=p?.stock??"";$("pCategory").value=p?.category||"";$("pImage").value=p?.image||"";$("pDescription").value=p?.description||"";
  $("productModal").classList.remove("hidden");
}
function editProduct(p){openProductForm(p)}
$("productForm").onsubmit=async e=>{
  e.preventDefault();
  const id=$("productId").value;
  const body={name:$("pName").value,price:Number($("pPrice").value),stock:Number($("pStock").value),category:$("pCategory").value,image:$("pImage").value,description:$("pDescription").value};
  try{
    await api(id?`/products/${id}`:"/products",{method:id?"PUT":"POST",body:JSON.stringify(body)});
    closeModal("productModal");toast("Product saved");showAdmin();
  }catch(err){toast(err.message)}
};
async function deleteProduct(id){
  if(!confirm("Delete this product?"))return;
  try{await api(`/products/${id}`,{method:"DELETE"});toast("Product deleted");showAdmin()}catch(e){toast(e.message)}
}
async function updateStatus(id,status){
  try{await api(`/orders/${id}/status`,{method:"PATCH",body:JSON.stringify({status})});toast("Order status updated")}catch(e){toast(e.message)}
}

refreshNav();updateCartCount();loadProducts();
