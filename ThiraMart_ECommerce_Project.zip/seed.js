require("dotenv").config();
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const User = require("./models/User");
const Product = require("./models/Product");

async function seed() {
  await mongoose.connect(process.env.MONGODB_URI);

  await Product.deleteMany({});
  await User.deleteMany({});

  const adminPassword = await bcrypt.hash("Admin@123", 10);
  const userPassword = await bcrypt.hash("User@123", 10);

  await User.create({
    name: "Admin",
    email: "admin@thiramart.com",
    password: adminPassword,
    role: "admin"
  });

  await User.create({
    name: "Demo User",
    email: "user@thiramart.com",
    password: userPassword,
    role: "user"
  });

  await Product.insertMany([
    {
      name: "Wireless Headphones",
      description: "Comfortable Bluetooth headphones with rich sound.",
      price: 1499,
      category: "Electronics",
      stock: 25,
      image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80"
    },
    {
      name: "Smart Watch",
      description: "Fitness tracking and notifications on your wrist.",
      price: 2299,
      category: "Wearables",
      stock: 18,
      image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80"
    },
    {
      name: "Running Shoes",
      description: "Lightweight everyday running shoes.",
      price: 1899,
      category: "Fashion",
      stock: 30,
      image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=80"
    },
    {
      name: "Laptop Backpack",
      description: "Water-resistant backpack with laptop compartment.",
      price: 999,
      category: "Accessories",
      stock: 40,
      image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=800&q=80"
    },
    {
      name: "Mechanical Keyboard",
      description: "RGB mechanical keyboard for work and gaming.",
      price: 2499,
      category: "Electronics",
      stock: 15,
      image: "https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=800&q=80"
    },
    {
      name: "Desk Lamp",
      description: "Modern LED lamp for study and office desks.",
      price: 799,
      category: "Home",
      stock: 22,
      image: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=800&q=80"
    }
  ]);

  console.log("Database seeded.");
  console.log("Admin: admin@thiramart.com / Admin@123");
  console.log("User: user@thiramart.com / User@123");
  await mongoose.disconnect();
}

seed().catch(err => {
  console.error(err);
  process.exit(1);
});
