# Assignment Submission Notes

## Project title
E-Commerce Web Application

## Objective
Build a basic online store with product management and order tracking.

## Implemented requirements

1. Product catalog, add to cart and checkout
2. User login and role-based access (Admin/User)
3. Backend APIs for product and order management
4. MongoDB database integration
5. Order tracking and admin status updates
6. Responsive UI

## Screens to demonstrate

- Home / Product Catalog
- Login / Registration
- Cart
- Checkout
- My Orders
- Admin Dashboard
- Product Add/Edit/Delete
- Order Status Update

## Suggested submission description

"Developed a full-stack E-Commerce Web Application using HTML, CSS, JavaScript, Node.js, Express and MongoDB. The application provides product catalog, cart, checkout, JWT authentication, role-based Admin/User access, product CRUD operations, order management and order tracking."

## Important
Before submission, configure `.env` with a valid MongoDB connection string. Do not upload `.env` or `node_modules` to GitHub.
