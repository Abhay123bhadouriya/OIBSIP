const express = require("express");
const path = require("path");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "task-manager-demo-secret-change-me";

const db = new Database(path.join(__dirname, "tasks.db"));
db.pragma("foreign_keys = ON");

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'pending',
    priority TEXT NOT NULL DEFAULT 'medium',
    due_date TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`);

const demoEmail = "demo@example.com";
const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(demoEmail);
if (!existing) {
  const hash = bcrypt.hashSync("Demo@123", 10);
  const info = db.prepare("INSERT INTO users (name,email,password) VALUES (?,?,?)")
    .run("Demo User", demoEmail, hash);
  const insert = db.prepare(`
    INSERT INTO tasks (user_id,title,description,status,priority,due_date)
    VALUES (?,?,?,?,?,?)
  `);
  insert.run(info.lastInsertRowid, "Complete internship project",
    "Build and submit the task management application.", "in-progress", "high", "2026-08-26");
  insert.run(info.lastInsertRowid, "Test CRUD operations",
    "Verify create, update, delete and status filters.", "pending", "medium", "2026-08-20");
}

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

function auth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ message: "Authentication required." });

  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ message: "Invalid or expired session." });
  }
}

app.post("/api/register", (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password || password.length < 6) {
    return res.status(400).json({ message: "Name, email and a password of at least 6 characters are required." });
  }
  const normalized = email.trim().toLowerCase();
  try {
    const hash = bcrypt.hashSync(password, 10);
    const info = db.prepare("INSERT INTO users (name,email,password) VALUES (?,?,?)")
      .run(name.trim(), normalized, hash);
    const user = { id: Number(info.lastInsertRowid), name: name.trim(), email: normalized };
    const token = jwt.sign(user, JWT_SECRET, { expiresIn: "7d" });
    res.status(201).json({ token, user });
  } catch (e) {
    if (String(e.message).includes("UNIQUE")) {
      return res.status(409).json({ message: "An account with this email already exists." });
    }
    res.status(500).json({ message: "Could not create account." });
  }
});

app.post("/api/login", (req, res) => {
  const { email, password } = req.body;
  const user = db.prepare("SELECT * FROM users WHERE email = ?").get((email || "").trim().toLowerCase());
  if (!user || !bcrypt.compareSync(password || "", user.password)) {
    return res.status(401).json({ message: "Incorrect email or password." });
  }
  const safeUser = { id: user.id, name: user.name, email: user.email };
  const token = jwt.sign(safeUser, JWT_SECRET, { expiresIn: "7d" });
  res.json({ token, user: safeUser });
});

app.get("/api/me", auth, (req, res) => {
  const user = db.prepare("SELECT id,name,email,created_at FROM users WHERE id = ?").get(req.user.id);
  if (!user) return res.status(404).json({ message: "User not found." });
  res.json(user);
});

app.get("/api/tasks", auth, (req, res) => {
  const tasks = db.prepare(`
    SELECT id,title,description,status,priority,due_date,created_at,updated_at
    FROM tasks WHERE user_id = ? ORDER BY
    CASE status WHEN 'in-progress' THEN 1 WHEN 'pending' THEN 2 ELSE 3 END,
    CASE priority WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END,
    id DESC
  `).all(req.user.id);
  res.json(tasks);
});

app.post("/api/tasks", auth, (req, res) => {
  const { title, description = "", status = "pending", priority = "medium", due_date = null } = req.body;
  if (!title || !title.trim()) return res.status(400).json({ message: "Task title is required." });
  if (!["pending","in-progress","completed"].includes(status)) return res.status(400).json({ message: "Invalid status." });
  if (!["low","medium","high"].includes(priority)) return res.status(400).json({ message: "Invalid priority." });

  const info = db.prepare(`
    INSERT INTO tasks (user_id,title,description,status,priority,due_date)
    VALUES (?,?,?,?,?,?)
  `).run(req.user.id, title.trim(), description.trim(), status, priority, due_date || null);

  const task = db.prepare("SELECT * FROM tasks WHERE id = ?").get(info.lastInsertRowid);
  res.status(201).json(task);
});

app.put("/api/tasks/:id", auth, (req, res) => {
  const id = Number(req.params.id);
  const old = db.prepare("SELECT * FROM tasks WHERE id = ? AND user_id = ?").get(id, req.user.id);
  if (!old) return res.status(404).json({ message: "Task not found." });

  const title = (req.body.title ?? old.title).trim();
  const description = (req.body.description ?? old.description).trim();
  const status = req.body.status ?? old.status;
  const priority = req.body.priority ?? old.priority;
  const due_date = req.body.due_date ?? old.due_date;

  if (!title) return res.status(400).json({ message: "Task title is required." });

  db.prepare(`
    UPDATE tasks SET title=?,description=?,status=?,priority=?,due_date=?,updated_at=CURRENT_TIMESTAMP
    WHERE id=? AND user_id=?
  `).run(title, description, status, priority, due_date || null, id, req.user.id);

  res.json(db.prepare("SELECT * FROM tasks WHERE id = ?").get(id));
});

app.delete("/api/tasks/:id", auth, (req, res) => {
  const result = db.prepare("DELETE FROM tasks WHERE id = ? AND user_id = ?")
    .run(Number(req.params.id), req.user.id);
  if (!result.changes) return res.status(404).json({ message: "Task not found." });
  res.json({ message: "Task deleted successfully." });
});

app.patch("/api/tasks/:id/status", auth, (req, res) => {
  const { status } = req.body;
  if (!["pending","in-progress","completed"].includes(status)) {
    return res.status(400).json({ message: "Invalid status." });
  }
  const result = db.prepare(`
    UPDATE tasks SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND user_id=?
  `).run(status, Number(req.params.id), req.user.id);
  if (!result.changes) return res.status(404).json({ message: "Task not found." });
  res.json(db.prepare("SELECT * FROM tasks WHERE id = ?").get(Number(req.params.id)));
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`Task Manager running at http://localhost:${PORT}`);
});