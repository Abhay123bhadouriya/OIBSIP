const $ = id => document.getElementById(id);
let mode = "login";
let tasks = [];
let currentUser = null;

function toast(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 2600);
}

function setMode(newMode) {
  mode = newMode;
  document.querySelectorAll(".tab").forEach(t => t.classList.toggle("active", t.dataset.mode === mode));
  $("nameGroup").classList.toggle("hidden", mode !== "register");
  $("authBtn").textContent = mode === "login" ? "Login" : "Create account";
}

document.querySelectorAll(".tab").forEach(t => t.addEventListener("click", () => setMode(t.dataset.mode)));

$("authForm").addEventListener("submit", async e => {
  e.preventDefault();
  const body = {
    name: $("name").value,
    email: $("email").value,
    password: $("password").value
  };
  const endpoint = mode === "login" ? "/api/login" : "/api/register";
  try {
    const res = await fetch(endpoint, {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify(body)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message);
    localStorage.setItem("token", data.token);
    currentUser = data.user;
    showApp();
  } catch (err) { toast(err.message); }
});

function authHeaders() {
  return { "Content-Type": "application/json", "Authorization": "Bearer " + localStorage.getItem("token") };
}

async function showApp() {
  $("authView").classList.add("hidden");
  $("appView").classList.remove("hidden");
  $("welcomeName").textContent = currentUser.name;
  $("heroName").textContent = currentUser.name.split(" ")[0];
  await loadTasks();
}

async function loadTasks() {
  try {
    const res = await fetch("/api/tasks", {headers: authHeaders()});
    if (!res.ok) throw new Error("Session expired.");
    tasks = await res.json();
    renderTasks();
  } catch (err) {
    localStorage.removeItem("token");
    location.reload();
  }
}

function renderTasks() {
  const query = $("search").value.toLowerCase().trim();
  const filter = $("filter").value;
  const shown = tasks.filter(t =>
    (filter === "all" || t.status === filter) &&
    (t.title.toLowerCase().includes(query) || t.description.toLowerCase().includes(query))
  );

  $("totalCount").textContent = tasks.length;
  $("pendingCount").textContent = tasks.filter(t => t.status === "pending").length;
  $("progressCount").textContent = tasks.filter(t => t.status === "in-progress").length;
  $("completedCount").textContent = tasks.filter(t => t.status === "completed").length;

  $("taskGrid").innerHTML = shown.map(taskCard).join("");
  $("emptyState").classList.toggle("hidden", shown.length !== 0);
}

function taskCard(t) {
  const statusText = t.status === "in-progress" ? "In Progress" : t.status;
  const due = t.due_date ? new Date(t.due_date + "T00:00:00").toLocaleDateString("en-IN", {day:"2-digit",month:"short",year:"numeric"}) : "No due date";
  return `
    <article class="task-card">
      <div class="task-top">
        <span class="badge status-${t.status}">${statusText}</span>
        <span class="priority">${t.priority} priority</span>
      </div>
      <h3>${escapeHtml(t.title)}</h3>
      <p>${escapeHtml(t.description || "No description provided.")}</p>
      <div class="task-meta">
        <small>Due: ${due}</small>
        <div class="task-actions">
          ${t.status !== "completed" ? `<button class="small-btn" onclick="completeTask(${t.id})">✓ Done</button>` : ""}
          <button class="small-btn" onclick="editTask(${t.id})">Edit</button>
          <button class="small-btn" onclick="deleteTask(${t.id})">Delete</button>
        </div>
      </div>
    </article>`;
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
}

function openModal(task = null) {
  $("modal").classList.remove("hidden");
  $("modalTitle").textContent = task ? "Edit Task" : "Create Task";
  $("taskId").value = task?.id || "";
  $("taskTitle").value = task?.title || "";
  $("taskDescription").value = task?.description || "";
  $("taskStatus").value = task?.status || "pending";
  $("taskPriority").value = task?.priority || "medium";
  $("taskDue").value = task?.due_date || "";
}

function closeModal() { $("modal").classList.add("hidden"); }

$("newTaskBtn").addEventListener("click", () => openModal());
$("closeModal").addEventListener("click", closeModal);
$("modal").addEventListener("click", e => { if (e.target === $("modal")) closeModal(); });

$("taskForm").addEventListener("submit", async e => {
  e.preventDefault();
  const id = $("taskId").value;
  const body = {
    title: $("taskTitle").value,
    description: $("taskDescription").value,
    status: $("taskStatus").value,
    priority: $("taskPriority").value,
    due_date: $("taskDue").value || null
  };
  const res = await fetch(id ? `/api/tasks/${id}` : "/api/tasks", {
    method: id ? "PUT" : "POST",
    headers: authHeaders(),
    body: JSON.stringify(body)
  });
  const data = await res.json();
  if (!res.ok) return toast(data.message);
  closeModal();
  toast(id ? "Task updated." : "Task created.");
  await loadTasks();
});

window.editTask = id => {
  const task = tasks.find(t => t.id === id);
  if (task) openModal(task);
};

window.deleteTask = async id => {
  if (!confirm("Delete this task?")) return;
  const res = await fetch(`/api/tasks/${id}`, {method:"DELETE", headers:authHeaders()});
  const data = await res.json();
  if (!res.ok) return toast(data.message);
  toast("Task deleted.");
  await loadTasks();
};

window.completeTask = async id => {
  const res = await fetch(`/api/tasks/${id}/status`, {
    method:"PATCH", headers:authHeaders(), body:JSON.stringify({status:"completed"})
  });
  if (!res.ok) return toast("Could not update task.");
  toast("Task completed.");
  await loadTasks();
};

$("search").addEventListener("input", renderTasks);
$("filter").addEventListener("change", renderTasks);

$("logoutBtn").addEventListener("click", () => {
  localStorage.removeItem("token");
  location.reload();
});

(async function init() {
  const token = localStorage.getItem("token");
  if (!token) return;
  try {
    const res = await fetch("/api/me", {headers:authHeaders()});
    if (!res.ok) throw new Error();
    currentUser = await res.json();
    showApp();
  } catch {
    localStorage.removeItem("token");
  }
})();