# TaskFlow – Task Management Application

A full-stack internship project for creating, updating, tracking and deleting tasks.

## Features
- User registration and login
- JWT authentication and authorization
- SQLite database
- Create, read, update and delete (CRUD) tasks
- Task status: Pending, In Progress, Completed
- Priority: Low, Medium, High
- Due dates
- Search and status filtering
- Responsive design for desktop and mobile
- Demo account included

## Technology Stack
- Frontend: HTML5, CSS3, JavaScript
- Backend: Node.js, Express
- Database: SQLite with better-sqlite3
- Authentication: JWT + bcryptjs

## Run locally

1. Install Node.js (LTS).
2. Open this project folder in VS Code.
3. Open the terminal.
4. Run:

```bash
npm install
npm start
```

5. Open `http://localhost:3000`

## Demo login
Email: `demo@example.com`
Password: `Demo@123`

## API endpoints
- POST `/api/register`
- POST `/api/login`
- GET `/api/me`
- GET `/api/tasks`
- POST `/api/tasks`
- PUT `/api/tasks/:id`
- DELETE `/api/tasks/:id`
- PATCH `/api/tasks/:id/status`

## Internship submission
Upload the complete project folder to GitHub. Do not upload `node_modules`; run `npm install` after cloning.
The generated `tasks.db` is created automatically when the server first starts.
