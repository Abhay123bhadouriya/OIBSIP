# Task Management Application

GitHub-ready single-file version of the internship Task Management Application.

## Upload
Upload `index.html` directly into the root of a GitHub repository.

## Run
Open `index.html` in a browser, or enable GitHub Pages from the repository Settings.

## Features
- Register / Login demo
- Create, edit and delete tasks
- Task status and priority
- Due dates
- Search and filters
- Dashboard statistics
- Completion progress
- Responsive mobile/desktop UI
- Data persistence with browser localStorage

This version requires no npm, Node.js, database setup or external dependencies, so it is suitable for direct GitHub upload/GitHub Pages.
